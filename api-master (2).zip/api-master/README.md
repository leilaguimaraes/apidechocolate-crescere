## API

### Run Node

```
npm start
```

### Run Nodemon

```
npm run dev
```

### Run Lint

```
npm run lint
```

### Setup PM2 - Install PM2

```
npm run setup
```

### Run PM2 -

```
npm run pm2
```

## ENV

Criar arquivo **.env** do arquivo **.env.example**

```
MONGO_URL=
JWT_KEY=
```

npm run pm2

prepm2 -> npm install pm2 -g

predev -> executa

dev -> executa
